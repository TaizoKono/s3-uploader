# AWS S3 ファイルアップローダー

AWS S3にファイルをアップロードするためのDockerコンテナ化されたアプリケーションです。大容量ファイル（数十GB）の効率的なアップロードに対応しています。

## 機能

- マルチパートアップロード: 大きなファイルを複数の小さなパートに分割してアップロード
- プレフィックス分散: S3のパフォーマンス最適化のためのキー設計
- Amazon S3 Transfer Acceleration: 長距離ネットワーク転送の高速化
- 進捗表示: リアルタイムのアップロード進捗状況の表示
- Dockerコンテナ化: 簡単なデプロイと環境の一貫性を確保

## 技術スタック

- **フロントエンド**: React
- **バックエンド**: Node.js, Express
- **AWS SDK**: AWS SDK for JavaScript v3
- **コンテナ化**: Docker, Docker Compose
- **Webサーバー**: Nginx

## 前提条件

- Docker
- Docker Compose
- AWS S3バケット（Transfer Accelerationが有効化されていることが望ましい）

## セットアップと実行

1. リポジトリをクローン

```bash
git clone <repository-url>
cd s3-uploader
```

2. アプリケーションの起動

```bash
docker-compose up -d
```

3. ブラウザでアクセス

```
http://localhost
```

## S3バケットの設定

このアプリケーションを使用するには、S3バケットに以下の設定が必要です：

1. **CORS設定**

```json
{
  "CORSRules": [
    {
      "AllowedHeaders": ["*"],
      "AllowedMethods": ["PUT", "POST", "GET"],
      "AllowedOrigins": ["*"],
      "ExposeHeaders": ["ETag"]
    }
  ]
}
```

2. **Transfer Acceleration**

S3バケットのプロパティから「Transfer Acceleration」を有効化することで、アップロード速度を向上させることができます。

## 環境変数

バックエンドサービスは以下の環境変数を使用します：

- `AWS_ACCESS_KEY_ID`: AWS IAMアクセスキー
- `AWS_SECRET_ACCESS_KEY`: AWS IAMシークレットアクセスキー
- `AWS_REGION`: AWSリージョン（デフォルト: ap-northeast-1）
- `S3_BUCKET`: S3バケット名
- `PORT`: バックエンドサーバーのポート（デフォルト: 3001）

### 環境変数の設定方法

1. バックエンドディレクトリに`.env.example`ファイルをコピーして`.env`ファイルを作成します：

```bash
cp backend/.env.example backend/.env
```

2. `.env`ファイルを編集して、実際の値を設定します：

```
# AWS認証情報
AWS_ACCESS_KEY_ID=your_access_key_id
AWS_SECRET_ACCESS_KEY=your_secret_access_key
AWS_REGION=ap-northeast-1

# S3バケット設定
S3_BUCKET=your_bucket_name

# サーバー設定
PORT=3001
```

3. Docker Composeは自動的に`.env`ファイルから環境変数を読み込みます。

## アーキテクチャ

このアプリケーションは以下のコンポーネントで構成されています：

1. **フロントエンド（React）**
   - ファイル選択インターフェース
   - アップロード進捗表示
   - 完了通知

2. **バックエンド（Node.js/Express）**
   - S3マルチパートアップロードの管理
   - 署名付きURLの生成
   - CORSの設定

3. **Nginx**
   - 静的ファイルの配信
   - APIリクエストのプロキシ
   - 大容量ファイルのアップロード対応

## パフォーマンス最適化

- **チャンクサイズ**: デフォルトで5MBに設定されていますが、ネットワーク環境に応じて調整可能です
- **並列アップロード**: 複数のパートを同時にアップロードすることで転送速度を向上
- **プレフィックス分散**: ランダムなプレフィックスを使用してS3のパフォーマンスを最適化
- **Transfer Acceleration**: CloudFrontのエッジロケーションを活用して転送速度を向上

## 注意事項

- 認証情報はデモンストレーション目的で含まれています。実際の運用では環境変数や安全な認証情報管理サービスを使用してください。
- 大容量ファイルのアップロードはネットワーク帯域幅に依存します。
